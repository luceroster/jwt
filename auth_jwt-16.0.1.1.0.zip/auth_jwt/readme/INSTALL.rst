This module requires the ``pyjwt`` library to be installed.
